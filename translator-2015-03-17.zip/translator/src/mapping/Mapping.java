package mapping;

import java.io.*;
import java.net.URL;

import org.jdom.*;
import org.jdom.input.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class Mapping {
	static org.jdom.Document document;
	static Element racine;


	public static void init(){
		// On crée une instance de SAXBuilder
		SAXBuilder sxb = new SAXBuilder();
		try {
			// On crée un nouveau document JDOM avec en argument le fichier XML
			URL url = Mapping.class.getResource("mapping.xml");
			//System.out.println(url.getFile());
			document = sxb.build(new File(url.getFile()));
		} catch (Exception e) {
		}
		// On initialise un nouvel élément racine avec l'élément racine du
		// document.
		racine = document.getRootElement();
	}

	public static String toClass(String metaclass) {
		String to ="";
		List listmetaclasses = racine.getChildren("meta-class");
		Iterator i = listmetaclasses.iterator();
		while (i.hasNext()) {
			Element courant = (Element) i.next();
			if(courant.getAttributeValue("id").equals(metaclass)){
				to=(courant.getChild("name")).getAttributeValue("to");
			}
		}
		return to;
	}

	public static String toRole(String from) {
		String to ="";

		List listmetaclasses = racine.getChildren("meta-class");
		Iterator l = listmetaclasses.iterator();
		while (l.hasNext()) {
			Element courant0 = (Element) l.next();
			if(courant0.getAttributeValue("id").equals(from)){
				to=(courant0.getChild("name")).getAttributeValue("to");
				return to;
			}
		}
		Iterator i = listmetaclasses.iterator();
		while (i.hasNext()) {
			Element courant = (Element) i.next();
			List listroles = courant.getChildren("role");
			Iterator j = listroles.iterator();
			while (j.hasNext()) {
				Element courant2 = (Element) j.next();
				if(courant2.getAttributeValue("from").equals(from)){
					to=courant2.getAttributeValue("to");
					return to;
				}
			}
			List listnavigations = courant.getChildren("navigation");
			Iterator k = listnavigations.iterator();
			while (k.hasNext()) {
				Element courant3 = (Element) k.next();	
				if(courant3.getAttributeValue("from").equals(from)){
					to=courant3.getAttributeValue("to");
					return to;
				}


			}
		}

		return to;
	}

	public static Boolean isRole(String role){
		Boolean isrole = false;
		ArrayList listroles = new ArrayList<String>();
		List list=null;

		List listmetaclasses = racine.getChildren("meta-class");
		Iterator i = listmetaclasses.iterator();
		while (i.hasNext()) {
			Element courant = (Element) i.next();
			list = courant.getChildren("role");
			Iterator j = list.iterator();
			while (j.hasNext()) {
				Element courant2 = (Element) j.next();
				listroles.add(courant2.getAttributeValue("from"));
			}
		}	
		if(listroles.contains(role)) isrole=true;
		return isrole;
	}
	public static Boolean isMeta(String meta){
		Boolean ismeta = false;
		ArrayList listmetaclasses = new ArrayList<String>();
		List list=null;

		 list = racine.getChildren("meta-class");
		Iterator i = list.iterator();
		while (i.hasNext()) {
			Element courant = (Element) i.next();
			listmetaclasses.add(courant.getAttributeValue("id"));
		}	

		if(listmetaclasses.contains(meta)) ismeta=true;
		return ismeta;
	}
	
	public static ArrayList<String> isNavigation(){
		ArrayList listnavigations = new ArrayList<String>();
		List list=null;

		List listmetaclasses = racine.getChildren("meta-class");
		Iterator i = listmetaclasses.iterator();
		while (i.hasNext()) {
			Element courant = (Element) i.next();
			list = courant.getChildren("navigation");
			Iterator j = list.iterator();
			while (j.hasNext()) {
				Element courant2 = (Element) j.next();
				listnavigations.add(courant2.getAttributeValue("from"));
			}
		}	
		return listnavigations;
	}
	
	
	
	public static void main(String args[]){
		init();
		
		System.out.println("isRole "+toClass("Class"));
		System.out.println("isRole "+toClass("Stereotype"));
		System.out.println("isRole "+toRole("package.profileApplication.appliedProfile.ownedStereotype"));
		System.out.println("isRole "+isMeta("raisedException"));
		System.out.println("isRole "+isMeta("annotation"));
		System.out.println("isNavig "+isNavigation());
	}



}
