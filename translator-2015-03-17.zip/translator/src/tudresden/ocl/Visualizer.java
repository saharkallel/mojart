/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * OCL Compiler                                                      *
 * Copyright (C) 1999, 2000 Frank Finger (frank@finger.org).         *
 * All rights reserved.                                              *
 *                                                                   *
 * This work was done as a diploma project at the Chair for Software *
 * Technology, Dresden University Of Technology, Germany             *
 * (http://www-st.inf.tu-dresden.de).  It is understood that any     *
 * modification not identified as such is not covered by the         *
 * preceding statement.                                              *
 *                                                                   *
 * This work is free software; you can redistribute it and/or        *
 * modify it under the terms of the GNU Library General Public       *
 * License as published by the Free Software Foundation; either      *
 * version 2 of the License, or (at your option) any later version.  *
 *                                                                   *
 * This work is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU *
 * Library General Public License for more details.                  *
 *                                                                   *
 * You should have received a copy of the GNU Library General Public *
 * License along with this library; if not, write to the             *
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,      *
 * Boston, MA  02111-1307, USA.                                      *
 *                                                                   *
 * To submit a bug report, send a comment, or get the latest news on *
 * this project and other projects, please visit the web site:       *
 * http://www-st.inf.tu-dresden.de/ (Chair home page) or             *
 * http://www-st.inf.tu-dresden.de/ocl/ (project home page)          *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package tudresden.ocl;


import java.util.ArrayList;

import tudresden.ocl.check.TypeQueryable;
import tudresden.ocl.parser.analysis.*;
import tudresden.ocl.parser.node.*;
import javax.swing.tree.*;
import mapping.Mapping;


public class Visualizer extends DepthFirstAdapter {
	
	Start root;
	String errorMessage;
	RuntimeException exception;

	TypeQueryable tq;
	boolean catchExceptions;

	public Visualizer(boolean catchExceptions) {
		this(catchExceptions, null);
	}

	public Visualizer(boolean catchExceptions, TypeQueryable tq) {
		this.tq=tq;
		this.catchExceptions=catchExceptions;
	}

	public void inStart(Start node) {
		root=node;
		//System.out.println("node = "+ node);
		defaultIn(node);
	}

	public void outStart(Start s) {
		if (exception!=null) {
			throw exception;
		}
	}

	static ArrayList<String> ocl_contraint = new ArrayList<String>();
	static String contraint=""; 
	static String result ="";
	static ArrayList<String> listnode=new ArrayList<String>();
	Boolean logique = false; 

	/////////////////////////////////////////
//	Node parentnode=null;
//	final StringBuffer stringBufferforall = new StringBuffer();
//	final StringBuffer stringBufferincludes = new StringBuffer();
//	final StringBuffer stringBufferselect=new StringBuffer();
//	static int idforAll=0;
//	static Boolean includesdansforall=false;

	public void defaultIn(Node node) {
		String n=node.toString(); 
		String text=node.getClass().getName();
		text=text.substring(text.lastIndexOf(".")+1);
		if (text.startsWith("A")) text=text.substring(1);
		/////////////////////////////////////////////////////
//		if(text.equalsIgnoreCase("logicalExpressionTail")){
//			String pNode = node.parent().parent().parent().getClass().getName();
//			pNode= pNode.substring(pNode.lastIndexOf(".")+1);
//			//System.out.println("*"+pNode+"*");	
//			if(pNode.equalsIgnoreCase("AConstraintBody")){
//				logique = true;
//				//System.out.println("**************************************"+pNode+"*");
//			}           
//		}
//
//		if(text.equalsIgnoreCase("PathName")){
//			if(node.toString().equalsIgnoreCase("includes ")){
//				stringBufferincludes.append(".includes (");
//			}
//		}
//		if(text.equalsIgnoreCase("PathName")){
//			if(node.toString().equalsIgnoreCase("select ")){
//				stringBufferselect.append(".select (");
//			}
//		}
//		if(text.equalsIgnoreCase("PathName")){
//			//System.out.println("%"+node.toString()+"%");
//			if(node.toString().equalsIgnoreCase("forAll ")){
//				stringBufferforall.append(".each ([:"); 
//				forallgenerate(text, node);
//			}
//		}
//		
//		if(text.toString().equalsIgnoreCase("FeaturePrimaryExpression")){
//			parentnode = node.parent().parent().parent().parent().parent().parent().parent()
//			.parent().parent().parent().parent();
//			System.out.println("1");
//			//				if(parentnode != null){
//			//					System.out.println("kkkk"+parentnode.toString().substring(3,11)+"hhhhh");
//			//				}
//			if((parentnode != null) &&(parentnode.toString().substring(3,9)).equalsIgnoreCase("forAll")) {
//
//				//System.out.println(parentnode.toString().substring(3,9));
//				System.out.println("ok");
//				stringBufferforall.append(node.toString());
//			}
//			if((parentnode != null) &&(parentnode.toString().substring(3,11)).equalsIgnoreCase("includes")) {
//				System.out.println("okokok");
//				stringBufferincludes.append(node.toString());
//			}
//			if((parentnode != null) &&(parentnode.toString().substring(3,11)).equalsIgnoreCase("select")) {
//				System.out.println("okokokok");
//				stringBufferselect.append(node.toString());
//			}
//		}
//		if(text.toString().equalsIgnoreCase("PostfixExpressionTail")){
//			parentnode = node.parent().parent().parent().parent().parent().parent().parent()
//			.parent().parent().parent().parent();
//			//System.out.println("1111");
//			if((parentnode != null) &&(parentnode.toString().substring(3,9)).equalsIgnoreCase("forAll")) {
//				//Node node2=node;
//				if(!(node.toString().substring(0,2).equals("->"))){
//					//System.out.println( !(node.toString().substring(0,2).equals("->")));
//					stringBufferforall.append(node.toString());
//					System.out.println("3");
//				}
//				else {
//					System.out.println("ttttttt");
//					if(node.toString().indexOf("(")>3){
//						System.out.println("mm"+node.toString().substring(3, node.toString().indexOf("("))+"jj");
//						if(node.toString().substring(3, node.toString().indexOf("("))
//								.equalsIgnoreCase("includes ")){
//							//stringBufferforall.append(".includes");
//							System.out.println("2222222");
//							//stringBufferforall.append(stringBufferincludes.toString());
//							includesdansforall=true;
//
//						}
//					}
//				}
//			}
//			//stringBufferforall.append("]);");
//			if((parentnode != null) &&(parentnode.toString().substring(3,11)).equalsIgnoreCase("includes")) {
//				//Node node2=node;
//				System.out.println("eeeeeeeeeeeeeeeeee");
//				if(!(node.toString().substring(0,2).equals("->"))){
//					//System.out.println( !(node.toString().substring(0,2).equals("->")));
//					stringBufferincludes.append(node.toString());
//					System.out.println("3333333");
//							}
//				stringBufferincludes.append(")");
//			}
//		}
//		System.out.print(stringBufferforall.toString());
//		if(includesdansforall) System.out.println(stringBufferincludes.toString());
//	
		//////////////////////////////////////////////////////////
		text = text+" - "+n;

		if (tq!=null) {
			try {
				Object o=tq.getNodeType(node);
				if (o==null) {
					text=text+" - no type";
				} else {
					if(o.toString().equals("Stereotype")){
						if(!listnode.contains(node.toString()))
						{
							listnode.add(node.toString());			
						}
					}
					text = text+" - "+o;
				}
			} catch (RuntimeException e) {
				text = text + " - ERROR " + e.getMessage();
				errorMessage=e.getMessage();
				if (catchExceptions) {
					e.printStackTrace(System.out);
				} else {
					if (exception==null) exception=e;
				}
			}

		}

		DefaultMutableTreeNode dmtn=new DefaultMutableTreeNode(text);
		setIn(node, dmtn);
	}
//	public void forallgenerate(String text, Node node){
//		if(text.toString().equalsIgnoreCase("StandardDeclarator")){
//			stringBufferforall.append(node.toString().substring(0,1)+ "|");
//		}
//	}

	public void defaultOut(Node node) {
		Node parent=node.parent();
		if (parent!=null) {
			DefaultMutableTreeNode dmtn=(DefaultMutableTreeNode)getIn(parent);
			//MutableTreeNode mtn=(MutableTreeNode)getIn(node);
			dmtn.add((DefaultMutableTreeNode)getIn(node));			
		}
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	static String cons="";
	int i=1;
	static String buffer="";

	public void defaultCase(Node node) {
		// called for Tokens only -> this is a leaf node
		//System.out.println("Type= "+tq.getNodeType(node)+" /////Node= " +node.toString().trim());
		if(getErrorMessage()== null || getErrorMessage().equals("")){

			Mapping.init();
			if(Mapping.isMeta(node.toString().trim())==false && Mapping.isRole(node.toString().trim())==false) {
				//System.out.println("0 TRUE");
				ocl_contraint.add(node.toString().trim());
				contraint=contraint+" "+ocl_contraint.get(ocl_contraint.size()-1);
			}
			if(Mapping.isMeta(node.toString().trim())){
				//System.out.println("1 TRUE");
				Token t = (Token)node;
				t.setText(Mapping.toClass(node.toString().trim()));
				ocl_contraint.add(t.getText());
				contraint=contraint+" "+t.getText();
			}

			if(Mapping.isRole(node.toString().trim())) {
				//System.out.println("2 TRUE");
				Token t1 = (Token)node;
				t1.setText(Mapping.toRole(node.toString().trim()));
				ocl_contraint.add(t1.getText());
				contraint=contraint+" "+t1.getText();	
			}

			ArrayList<String> list = Mapping.isNavigation();
			contraint = contraint.replaceAll(" \\. ", "\\.");
			for(int j =0;j<list.size();j++){
				if(contraint.trim().contains(list.get(j))) {
					contraint=contraint.replaceAll(list.get(j), Mapping.toRole(list.get(j)));
				}		
			}
		}
		else {
			result = getErrorMessage();
		}

		String n=node.toString();
		String text=node.getClass().toString();
		text=text.substring(text.lastIndexOf(".")+1);
		if (text.startsWith("T")) text=text.substring(1);
		//////////////////////////////////////////
		//System.out.println("CLASS T : "+ text);
		cons=cons+node.toString().trim()+"";
		//System.out.println("cons"+cons);
		if(logique==true){
			buffer=buffer+"*"+cons;
			cons="";
			logique = false;
		}
		//////////////////////////////////////
		text = text+" - "+n;


		DefaultMutableTreeNode dmtn=new DefaultMutableTreeNode(text);
		((DefaultMutableTreeNode)getIn(node.parent())).add(dmtn);
	}


	public DefaultMutableTreeNode getRootNode() {
		return (DefaultMutableTreeNode) getIn(root);
	}
}
